package com.cestasoft.bankingengine.db;
 
import com.mongodb.client.*;
import static com.mongodb.client.model.Filters.eq;
 
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.synapse.MessageContext;
import org.apache.synapse.config.SynapseConfiguration;
import org.apache.synapse.mediators.AbstractMediator;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.json.JSONObject;
import com.fasterxml.jackson.databind.ObjectMapper;
 
 
import java.util.HashMap;
import java.util.Map;
 
public class SelectData extends AbstractMediator {
 
	 private static final Log log = LogFactory.getLog(SelectData.class);
	    private static volatile MongoClient mongoClient;
 
	    private static final String RSOP = "rsopservices";
	    private static final String BILLERS = "billers";
	    private static final String USERS = "api_users";
	    private static final String RESPONSES = "responses";
	    private static final String REQUESTS = "requests";
	    private static final ObjectMapper mapper = new ObjectMapper();
 
	    @Override
	    public boolean mediate(MessageContext mc) {
 
	        try {

 
	        	 String dbConnectionConfig = (String) mc.getProperty("database.config.local.entry");
	        	JSONObject json = new JSONObject(dbConnectionConfig.toString());
 
		        mc.setProperty("mongo.host", json.optString("host", "localhost"));
		        mc.setProperty("mongo.port", json.optString("port", "27017"));
		        mc.setProperty("mongo.database", json.optString("database", "biller-host"));
		        mc.setProperty("mongo.username", json.optString("username", ""));
		        mc.setProperty("mongo.password", json.optString("password", ""));

	            initializeMongo(mc);      // Step 2: Create client using properties
 
	            String bhid = (String) mc.getProperty("bhid");

 
	            if (bhid == null || bhid.isBlank()) {
	                log.warn("Invalid BHID");
	                return true;
	            }
 
	            String databaseName = (String) mc.getProperty("mongo.database");
 
	            MongoDatabase database =
	                    mongoClient.getDatabase(databaseName);
 
	            Map<String, String> spOpServiceMap =
	                    getById(database, RSOP, bhid);
 
	            if (spOpServiceMap.isEmpty()) {
	                log.warn("No service document found");
	                return true;
	            }
 
	            String ownerName = spOpServiceMap.get("ownername");
 
	            Map<String, String> billerMap =
	                    getByField(database, BILLERS, "name", ownerName);
 
	            Map<String, String> apiUsersMap =
	                    getByField(database, USERS, "biller", ownerName);
 
	            Map<String, String> responseMap =
	                    getByField(database, RESPONSES, "bhid", bhid);
 
	            Map<String, String> requestMap =
	                    getByField(database, REQUESTS, "bhid", bhid);
 
	            setIfPresent(mc, "protocolType", spOpServiceMap, "protocoltype");
	            setIfPresent(mc, "ownerName", spOpServiceMap, "ownername");
	            setIfPresent(mc, "webServiceName", spOpServiceMap, "name");
	            setIfPresent(mc, "secMode", spOpServiceMap, "secmode");
	            setIfPresent(mc, "actionType", spOpServiceMap, "actiontype");
	            setIfPresent(mc, "encValue", spOpServiceMap, "encvalue");
	            setIfPresent(mc, "partnerId", spOpServiceMap, "encvalue");
	            setIfPresent(mc, "secValue", spOpServiceMap, "secvalue");
	            setIfPresent(mc, "wSoapto", spOpServiceMap, "wsoapto");
	            setIfPresent(mc, "httpOperation", spOpServiceMap, "httpoperation");
	            setIfPresent(mc, "headersList", spOpServiceMap, "headersList");
	            setIfPresent(mc, "headersStaticFlag", spOpServiceMap, "headersStaticFlag");
	            setIfPresent(mc, "headersSequence", spOpServiceMap, "headersSequence");
	            setIfPresent(mc, "signingSecret", spOpServiceMap, "signingsecret");
	            setIfPresent(mc, "authTokenApi", spOpServiceMap, "authtokenapi");
	            setIfPresent(mc, "authTokenPayload", spOpServiceMap, "authtokenpayload");
	            setIfPresent(mc, "authTokenSequence", spOpServiceMap, "authtokensequence");
 
	            
	            mc.setProperty("wsSpOpServiceMap", spOpServiceMap);
	            mc.setProperty("wsBillerMap", billerMap);
	            mc.setProperty("wsRequestMap", requestMap);
	            mc.setProperty("wsResponseMap", responseMap);
	            mc.setProperty("wsApiUserMap", apiUsersMap);
 
	        } catch (Exception e) {
	            log.error("Error in SelectData", e);
	        }
 
	        return true;
	    }
 
	   
 
	    // -----------------------------------
	    // STEP 2: Initialize MongoClient
	    // -----------------------------------
 
	    private void initializeMongo(MessageContext mc) {
 
	        if (mongoClient != null) return;
 
	        synchronized (SelectData.class) {
 
	            if (mongoClient != null) return;
 
	            String host = (String) mc.getProperty("mongo.host");
	            String port = (String) mc.getProperty("mongo.port");
	            String username = (String) mc.getProperty("mongo.username");
	            String password = (String) mc.getProperty("mongo.password");
 
	            String uri;
 
	            if (username != null && !username.isBlank()
&& password != null && !password.isBlank()) {
 
	                uri = "mongodb://" + username + ":" + password +
	                        "@" + host + ":" + port;
 
	                log.info("Mongo initialized WITH auth");
 
	            } else {
 
	                uri = "mongodb://" + host + ":" + port;
	                log.info("Mongo initialized WITHOUT auth");
	            }
 
	            mongoClient = MongoClients.create(uri);
	        }
	    }
 
	    // -----------------------------------
	    // DB Helpers
	    // -----------------------------------
 
	    private Map<String, String> getById(MongoDatabase db,
	                                        String collection,
	                                        String id) {
 
	        Document doc = db.getCollection(collection)
	                .find(eq("_id", new ObjectId(id)))
	                .first();
 
	        return documentToMap(doc);
	    }
 
	    private Map<String, String> getByField(MongoDatabase db,
	                                           String collection,
	                                           String field,
	                                           String value) {
 
	        Document doc = db.getCollection(collection)
	                .find(eq(field, value))
	                .first();
 
	        return documentToMap(doc);
	    }
 
	    private Map<String, String> documentToMap(Document doc) {
	        Map<String, String> map = new HashMap<>();
 
	        if (doc != null) {
	            doc.forEach((k, v) -> {
	                try {
	                    if (v instanceof java.util.List) {
	                        map.put(k, mapper.writeValueAsString(v));
	                    } else {
	                        map.put(k, v != null ? v.toString() : null);
	                    }
	                } catch (Exception e) {
	                    log.error("Error converting value for key: " + k, e);
	                }
	            });
	        }
 
	        return map;
	    }
 
	    
	    private void setIfPresent(MessageContext mc,
                String propertyName,
                Map<String,String> map,
                String mapKey) {
 
String value = map.get(mapKey);
 
if (value != null && !value.isBlank()) {
mc.setProperty(propertyName, value);
log.debug("Set property: " + propertyName + " = " + value);
} else {
log.warn("Missing key in DB: " + mapKey);
}
}
 
	    
}