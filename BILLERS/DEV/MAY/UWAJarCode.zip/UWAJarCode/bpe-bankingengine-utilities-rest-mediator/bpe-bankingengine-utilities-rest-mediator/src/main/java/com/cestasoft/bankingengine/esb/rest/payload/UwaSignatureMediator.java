package com.cestasoft.bankingengine.esb.rest.payload;
 
import org.apache.synapse.MessageContext;
import org.apache.synapse.mediators.AbstractMediator;
import org.apache.synapse.core.axis2.Axis2MessageContext;
import org.apache.synapse.commons.json.JsonUtil;
 
 
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
 
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
 
 
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;
import java.net.URI;
 
public class UwaSignatureMediator extends AbstractMediator {
	private static final Log log =
            LogFactory.getLog(UwaSignatureMediator.class);
 
	private static final String HMAC_ALGO = "HmacSHA256";
	private  final  ObjectMapper objectMapper = new ObjectMapper();

	private String signingSecret;
    private String httpMethod;
    private String apiURL;
 
    // Setter method (MANDATORY)
    public void setSigningSecret(String signingSecret) {
        this.signingSecret = signingSecret;
    }
 
    public void setHttpMethod(String httpMethod) {
        this.httpMethod = httpMethod;
    }
 
    public void setApiURL(String apiURL) {
        this.apiURL = apiURL;
    }

 
	@Override
	public boolean mediate(MessageContext context) {
 
		try {
			Axis2MessageContext axis2Ctx = (Axis2MessageContext) context;
 
			org.apache.axis2.context.MessageContext axis2MsgCtx = axis2Ctx.getAxis2MessageContext();

			//String signingSecret = (String) axis2MsgCtx.getProperty("signingSecret");
			//String SIGNING_SECRET = "integra@2026!UAT";

			log.info("SIGNING_SECRET = [" + signingSecret + "]");
 
			/*
			 * ------------------------------- 1. METHOD -------------------------------
			 */
			//String method = (String) axis2MsgCtx.getProperty("HTTP_METHOD");
			/*
			 * if (method == null) { method = "POST"; }
			 */
			httpMethod = httpMethod.toUpperCase();
			log.info("[UWA-SIGN] METHOD = [" + httpMethod + "]");
 
			/*
			 * ------------------------------- 2. PATH (from queryUrl)
			 * -------------------------------
			 */
			//String queryUrl = (String) context.getProperty("wsoapto");


			if (apiURL == null || apiURL.isEmpty()) {
			    log.error("[UWA-SIGN] apiURL is NULL or EMPTY. Cannot build signature.");
			    throw new RuntimeException("apiURL not set before signature generation");
			}

			URI uri = new URI(apiURL);
			String path = uri.getPath(); // exact path only
			log.info("[UWA-SIGN] PATH = [" + path + "]");
 
			/*
			 * ------------------------------- 3. TRANSPORT HEADERS
			 * -------------------------------
			 */
			@SuppressWarnings("unchecked")
			Map<String, Object> headers = (Map<String, Object>) axis2MsgCtx
					.getProperty(org.apache.axis2.context.MessageContext.TRANSPORT_HEADERS);
 
			String timestamp = headers.get("X-Timestamp").toString();
			String nonce = headers.get("X-Nonce").toString();
			log.info("[UWA-SIGN] TIMESTAMP = [" + timestamp + "]");
			log.info("[UWA-SIGN] NONCE = [" + nonce + "]");
 
			/*
			 * ------------------------------- 4. CANONICAL BODY
			 * -------------------------------
			 */
			String canonicalBody = "";
 
			if (JsonUtil.hasAJsonPayload(axis2MsgCtx)) {
				 String jsonString = JsonUtil.jsonPayloadToString(axis2MsgCtx);
				 // Parse JSON
				    JsonNode jsonNode = objectMapper.readTree(jsonString);
 
				    // Convert to compact JSON (no spaces/newlines)
				     canonicalBody = objectMapper.writeValueAsString(jsonNode);
			}
			/*
			 * ------------------------------- 5. BASE STRING
			 * -------------------------------
			 */



			log.info("[UWA-SIGN] CANONICAL_BODY = [" + canonicalBody + "]");

			String baseString = httpMethod + "\n" + path + "\n" + timestamp + "\n" + nonce + "\n" + canonicalBody;
			log.info("[UWA-SIGN] baseString = [" + baseString + "]");
 
			/*
			 * ------------------------------- 6. SIGNATURE -------------------------------
			 */

			log.info("baseString = [" + baseString + "]");

			Mac mac = Mac.getInstance(HMAC_ALGO);
			SecretKeySpec keySpec = new SecretKeySpec(signingSecret.getBytes(StandardCharsets.UTF_8), HMAC_ALGO);
			mac.init(keySpec);


 
			
 
			byte[] rawHmac = mac.doFinal(baseString.getBytes(StandardCharsets.UTF_8));
 
			String signature = Base64.getEncoder().encodeToString(rawHmac);
 
			/*
			 * ------------------------------- 7. OUTPUT -------------------------------
			 */
			context.setProperty("DYNAMIC_HEADER_VALUE", signature);
 
			return true;
 
		} catch (Exception e) {
			handleException("UWA signature generation failed", e, context);
			return false;
		}
	}
}