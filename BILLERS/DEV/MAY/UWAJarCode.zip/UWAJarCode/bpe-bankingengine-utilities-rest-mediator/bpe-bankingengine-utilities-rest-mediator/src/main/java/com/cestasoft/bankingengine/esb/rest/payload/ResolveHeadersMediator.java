package com.cestasoft.bankingengine.esb.rest.payload;


import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.synapse.MessageContext;
import org.apache.synapse.Mediator;
import org.apache.synapse.config.SynapseConfiguration;
import org.apache.synapse.mediators.AbstractMediator;
import org.apache.synapse.core.axis2.Axis2MessageContext;

import java.util.HashMap;
import java.util.Map;

public class ResolveHeadersMediator extends AbstractMediator {

    private static final ObjectMapper mapper = new ObjectMapper();
    private static final String DYNAMIC_HEADER_VALUE = "DYNAMIC_HEADER_VALUE";

    @Override
    public boolean mediate(MessageContext context) {

        try {
            /* -------------------------------------------------
             * 1. Read properties (STRING JSON arrays)
             * ------------------------------------------------- */
            String headersListStr = (String) context.getProperty("headersList");
            String headersStaticFlagStr = (String) context.getProperty("headersStaticFlag");
            String headersSequenceStr = (String) context.getProperty("headersSequence");

            if (headersListStr == null || headersListStr.isEmpty()) {
                return true; // nothing to do
            }

            JsonNode headersList = mapper.readTree(headersListStr);
            JsonNode headersStaticFlag =
                    headersStaticFlagStr != null ? mapper.readTree(headersStaticFlagStr) : null;
            JsonNode headersSequence =
                    headersSequenceStr != null ? mapper.readTree(headersSequenceStr) : null;

            /* -------------------------------------------------
             * 2. Prepare transport headers map
             * ------------------------------------------------- */
            Axis2MessageContext axis2Ctx = (Axis2MessageContext) context;
            org.apache.axis2.context.MessageContext axis2MsgCtx =
                    axis2Ctx.getAxis2MessageContext();

            @SuppressWarnings("unchecked")
            Map<String, Object> transportHeaders =
                    (Map<String, Object>) axis2MsgCtx.getProperty(
                            org.apache.axis2.context.MessageContext.TRANSPORT_HEADERS
                    );

            if (transportHeaders == null) {
                transportHeaders = new HashMap<>();
                axis2MsgCtx.setProperty(
                        org.apache.axis2.context.MessageContext.TRANSPORT_HEADERS,
                        transportHeaders
                );
            }

            /* -------------------------------------------------
             * 3. Access Synapse configuration (for sequences)
             * ------------------------------------------------- */
            SynapseConfiguration synCfg = context.getConfiguration();

            /* -------------------------------------------------
             * 4. Iterate arrays by index
             * ------------------------------------------------- */
            for (int i = 0; i < headersList.size(); i++) {

                String headerName = headersList.get(i).asText();

                String isStatic =
                        headersStaticFlag != null && headersStaticFlag.size() > i
                                ? headersStaticFlag.get(i).asText()
                                : "true";

                String seqOrValue =
                        headersSequence != null && headersSequence.size() > i
                                ? headersSequence.get(i).asText()
                                : "";

                String headerValue = "";

                if ("true".equalsIgnoreCase(isStatic)) {
                    // Static header
                    headerValue = seqOrValue;

                } else {
                    // Dynamic header → sequence name
                    if (seqOrValue != null && !seqOrValue.isEmpty()) {

                        Mediator seq = synCfg.getSequence(seqOrValue);

                        if (seq != null) {
                            // Clear previous dynamic value
                            context.setProperty(DYNAMIC_HEADER_VALUE, null);

                            // Execute sequence
                            seq.mediate(context);

                            Object dynVal = context.getProperty(DYNAMIC_HEADER_VALUE);
                            if (dynVal != null) {
                                headerValue = dynVal.toString();
                            }
                        } else {
                            log.warn("Header sequence not found: " + seqOrValue);
                        }
                    }
                }

                /* -------------------------------------------------
                 * 5. Set header (dynamic name + value)
                 * ------------------------------------------------- */
                if (headerName != null && !headerName.isEmpty()) {
                    transportHeaders.put(headerName, headerValue);
                }
            }

            return true;

        } catch (Exception e) {
            handleException("ResolveHeadersMediator failed", e, context);
            return false;
        }
    }
}
