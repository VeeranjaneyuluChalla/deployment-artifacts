package com.cestasoft.bankingengine.esb.rest.payload;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.synapse.MessageContext;
import org.apache.synapse.mediators.AbstractMediator;
import org.apache.synapse.commons.json.JsonUtil;
import org.apache.synapse.core.axis2.Axis2MessageContext;

public class DataArrayToJsonMediator extends AbstractMediator {

    private static final ObjectMapper mapper = new ObjectMapper();

    @Override
    public boolean mediate(MessageContext context) {
        try {
            Axis2MessageContext axis2Ctx =
                    (Axis2MessageContext) context;

            org.apache.axis2.context.MessageContext axis2MsgCtx =
                    axis2Ctx.getAxis2MessageContext();

            // Read JSON payload
            String jsonPayload = JsonUtil.jsonPayloadToString(axis2MsgCtx);

            JsonNode rootNode = mapper.readTree(jsonPayload);
            ArrayNode dataArray = (ArrayNode) rootNode.get("data");

            ObjectNode outputJson = mapper.createObjectNode();

            for (JsonNode item : dataArray) {
                String name = item.get("name").asText();
                JsonNode valueNode = item.get("value");

                if (valueNode.isArray()) {
                    ObjectNode nestedObject = mapper.createObjectNode();

                    for (JsonNode nestedItem : valueNode) {
                        nestedObject.set(
                                nestedItem.get("name").asText(),
                                nestedItem.get("value")
                        );
                    }
                    outputJson.set(name, nestedObject);
                } else {
                    outputJson.set(name, valueNode);
                }
            }

            // 🔑 Correct MI way to set JSON payload
            JsonUtil.newJsonPayload(
                    axis2MsgCtx,
                    outputJson.toString(),
                    true,
                    true
            );

            return true;

        } catch (Exception e) {
            handleException("Error converting data array to JSON payload", e, context);
            return false;
        }
    }
}
